import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Router, Route, Switch } from "wouter";
import Dashboard from "./pages/dashboard";
import ThreatReports from "./pages/threat-reports";
import QuantumEncryption from "./pages/quantum-encryption";
import SystemMetrics from "./pages/system-metrics";
import EmergencyProtocols from "./pages/emergency-protocols";
import FAQ from "./pages/faq";
import HowTo from "./pages/how-to";
import HowToDetail from "./pages/how-to-detail";
import AdminPanel from "./pages/admin";
// Removed ZebulonInterface - using configuration approach instead
import { Toaster } from "@/components/ui/toaster";
import "./index.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Switch>
          <Route path="/" component={Dashboard} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/threat-reports" component={ThreatReports} />
          <Route path="/quantum-encryption" component={QuantumEncryption} />
          <Route path="/system-metrics" component={SystemMetrics} />
          <Route path="/emergency-protocols" component={EmergencyProtocols} />
          <Route path="/faq" component={FAQ} />
          <Route path="/how-to" component={HowTo} />
          <Route path="/how-to/:id" component={HowToDetail} />
          <Route path="/admin" component={AdminPanel} />
          {/* Removed hardcoded integrations - using configuration guides instead */}
          <Route path="/corporate-sabotage" component={ThreatReports} />
          <Route component={Dashboard} />
        </Switch>
        <Toaster />
      </Router>
    </QueryClientProvider>
  );
}

export default App;
