import { useState, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";

declare global {
  interface Window {
    ethereum?: any;
  }
}

export interface WalletState {
  account: string | null;
  isConnected: boolean;
  isConnecting: boolean;
  chainId: number | null;
  error: string | null;
}

export type WalletType = "metamask" | "coinbase" | "other";

export function useWallet() {
  const { toast } = useToast();
  const [walletState, setWalletState] = useState<WalletState>({
    account: null,
    isConnected: false,
    isConnecting: false,
    chainId: null,
    error: null,
  });
  const [connectedWalletType, setConnectedWalletType] = useState<WalletType | null>(null);

  // Detect available wallets
  const getAvailableWallets = () => {
    const wallets = [];
    
    if (window.ethereum?.isMetaMask) {
      wallets.push({ type: "metamask" as WalletType, name: "MetaMask", icon: "🦊" });
    }
    if (window.ethereum?.isCoinbaseWallet) {
      wallets.push({ type: "coinbase" as WalletType, name: "Coinbase Wallet", icon: "🔵" });
    }
    if (window.ethereum && !window.ethereum.isMetaMask && !window.ethereum.isCoinbaseWallet) {
      wallets.push({ type: "other" as WalletType, name: "Web3 Wallet", icon: "🔗" });
    }
    
    return wallets;
  };

  // Check if wallet is already connected - only in production or when explicitly requested
  useEffect(() => {
    // Skip automatic wallet connection in development environment
    if (process.env.NODE_ENV === 'development') {
      return;
    }

    const checkConnection = async () => {
      if (!window.ethereum) return;

      try {
        const accounts = await window.ethereum.request({ method: 'eth_accounts' });
        if (accounts.length > 0) {
          const chainId = await window.ethereum.request({ method: 'eth_chainId' });
          setWalletState({
            account: accounts[0],
            isConnected: true,
            isConnecting: false,
            chainId: parseInt(chainId, 16),
            error: null,
          });
          
          // Detect wallet type
          if (window.ethereum.isMetaMask) {
            setConnectedWalletType("metamask");
          } else if (window.ethereum.isCoinbaseWallet) {
            setConnectedWalletType("coinbase");
          } else {
            setConnectedWalletType("other");
          }
        }
      } catch (error) {
        // Silently handle wallet connection errors in development
        console.warn("Wallet connection check failed (this is normal in development):", error);
      }
    };

    checkConnection();
  }, []);

  // Listen for account changes - only when wallet is available
  useEffect(() => {
    if (!window.ethereum || process.env.NODE_ENV === 'development') return;

    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        setWalletState(prev => ({
          ...prev,
          account: null,
          isConnected: false,
          error: null,
        }));
        toast({
          title: "Wallet Disconnected",
          description: "Your wallet has been disconnected",
          variant: "destructive",
        });
      } else {
        setWalletState(prev => ({
          ...prev,
          account: accounts[0],
          isConnected: true,
          error: null,
        }));
      }
    };

    const handleChainChanged = (chainId: string) => {
      setWalletState(prev => ({
        ...prev,
        chainId: parseInt(chainId, 16),
      }));
    };

    try {
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);
    } catch (error) {
      console.warn("Could not set up wallet event listeners:", error);
    }

    return () => {
      try {
        if (window.ethereum?.removeListener) {
          window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
          window.ethereum.removeListener('chainChanged', handleChainChanged);
        }
      } catch (error) {
        console.warn("Could not remove wallet event listeners:", error);
      }
    };
  }, [toast]);

  const connectWallet = useCallback(async (walletType?: WalletType) => {
    if (!window.ethereum) {
      setWalletState(prev => ({
        ...prev,
        error: "Web3 wallet not found. Please install MetaMask or another Web3 wallet.",
      }));
      toast({
        title: "Wallet Not Found",
        description: "Please install MetaMask or a compatible Web3 wallet",
        variant: "destructive",
      });
      return;
    }

    setWalletState(prev => ({ ...prev, isConnecting: true, error: null }));

    try {
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts',
      });

      const chainId = await window.ethereum.request({ method: 'eth_chainId' });

      setWalletState({
        account: accounts[0],
        isConnected: true,
        isConnecting: false,
        chainId: parseInt(chainId, 16),
        error: null,
      });

      // Set wallet type
      if (walletType) {
        setConnectedWalletType(walletType);
      } else if (window.ethereum.isMetaMask) {
        setConnectedWalletType("metamask");
      } else if (window.ethereum.isCoinbaseWallet) {
        setConnectedWalletType("coinbase");
      } else {
        setConnectedWalletType("other");
      }

      const walletName = connectedWalletType === "metamask" ? "MetaMask" : 
                        connectedWalletType === "coinbase" ? "Coinbase Wallet" : "Web3 Wallet";

      toast({
        title: "Wallet Connected",
        description: `Connected ${walletName}: ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)}`,
      });
    } catch (error: any) {
      setWalletState(prev => ({
        ...prev,
        isConnecting: false,
        error: error.message || "Failed to connect wallet",
      }));
      
      if (error.code === 4001) {
        toast({
          title: "Connection Rejected",
          description: "User rejected the connection request",
          variant: "destructive",
        });
      } else {
        console.warn("Suppressed MetaMask error:", error);
        // Don't show toast in development environment to avoid spam
        if (process.env.NODE_ENV !== 'development') {
          toast({
            title: "Connection Failed",
            description: error.message || "Failed to connect wallet",
            variant: "destructive",
          });
        }
      }
    }
  }, [toast, connectedWalletType]);

  const disconnectWallet = useCallback(() => {
    setWalletState({
      account: null,
      isConnected: false,
      isConnecting: false,
      chainId: null,
      error: null,
    });
    setConnectedWalletType(null);
    toast({
      title: "Wallet Disconnected",
      description: "Your wallet has been disconnected",
    });
  }, [toast]);

  const switchToEthereum = useCallback(async () => {
    if (!window.ethereum) return;

    try {
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: '0x1' }], // Ethereum mainnet
      });
    } catch (error: any) {
      console.error('Error switching to Ethereum:', error);
      toast({
        title: "Network Switch Failed",
        description: "Failed to switch to Ethereum network",
        variant: "destructive",
      });
    }
  }, [toast]);

  return {
    ...walletState,
    connectWallet,
    disconnectWallet,
    switchToEthereum,
    connectedWalletType,
    getAvailableWallets,
    isWalletAvailable: !!window.ethereum,
  };
}