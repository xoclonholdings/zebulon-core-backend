import { useEffect, useRef, useState } from 'react';
import { io, Socket } from 'socket.io-client';

interface SecurityUpdate {
  zetaCore: {
    aiConfidence: number;
    neuralProcessing: number;
    isActive: boolean;
    analysisPatterns: number;
    threatsBlocked: number;
  };
  threatCounters: {
    aiInjection: number;
    corporateSabotage: number;
    marketManipulation: number;
    totalBlocked: number;
  };
  securityEvents: any[];
  systemMetrics: any[];
  zwapProtection: any[];
  encryptionLayers: any[];
  networkNodes: any[];
  timestamp: string;
}

export function useSocket() {
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [securityData, setSecurityData] = useState<SecurityUpdate | null>(null);

  useEffect(() => {
    // Connect to the socket server
    const socket = io(window.location.origin);
    socketRef.current = socket;

    socket.on('connect', () => {
      setIsConnected(true);
      console.log('Connected to Fantasma Firewall SOC');
    });

    socket.on('disconnect', () => {
      setIsConnected(false);
      console.log('Disconnected from Fantasma Firewall SOC');
    });

    socket.on('connect_error', (error) => {
      console.warn('Socket connection error:', error.message);
      setIsConnected(false);
    });

    socket.on('initialData', (data: Partial<SecurityUpdate>) => {
      try {
        setSecurityData(prev => ({ ...prev, ...data } as SecurityUpdate));
      } catch (error) {
        console.warn('Error processing initial data:', error);
      }
    });

    socket.on('securityUpdate', (data: SecurityUpdate) => {
      try {
        setSecurityData(data);
      } catch (error) {
        console.warn('Error processing security update:', error);
      }
    });

    socket.on('threatUpdated', (data: { eventId: number; status: string }) => {
      try {
        setSecurityData(prev => {
          if (!prev) return prev;
          
          const updatedEvents = prev.securityEvents.map(event => 
            event.id === data.eventId 
              ? { ...event, status: data.status }
              : event
          );
          
          return {
            ...prev,
            securityEvents: updatedEvents
          };
        });
      } catch (error) {
        console.warn('Error processing threat update:', error);
      }
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const refreshData = () => {
    try {
      if (socketRef.current && socketRef.current.connected) {
        socketRef.current.emit('refreshData');
      }
    } catch (error) {
      console.warn('Error refreshing data:', error);
    }
  };

  const investigateThreat = (eventId: number) => {
    try {
      if (socketRef.current && socketRef.current.connected) {
        socketRef.current.emit('investigateThreat', eventId);
      }
    } catch (error) {
      console.warn('Error investigating threat:', error);
    }
  };

  const resolveThreat = (eventId: number) => {
    try {
      if (socketRef.current && socketRef.current.connected) {
        socketRef.current.emit('resolveThreat', eventId);
      }
    } catch (error) {
      console.warn('Error resolving threat:', error);
    }
  };

  return {
    isConnected,
    securityData,
    refreshData,
    investigateThreat,
    resolveThreat
  };
}
