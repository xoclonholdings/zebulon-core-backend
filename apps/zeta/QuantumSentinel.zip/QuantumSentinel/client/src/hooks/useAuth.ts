import { useQuery, useMutation } from "@tanstack/react-query";
import { User } from "@shared/schema";
import { apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useWallet } from "./useWallet";

export function useAuth() {
  const { toast } = useToast();
  const { account, isConnected } = useWallet();
  
  const { data: user, error, isLoading } = useQuery<User | undefined, Error>({
    queryKey: ["/api/user", account],
    enabled: !!account && isConnected,
    retry: false,
  });

  const walletAuthMutation = useMutation({
    mutationFn: async (walletAddress: string) => {
      const res = await apiRequest("POST", "/api/wallet-auth", { walletAddress });
      return await res.json();
    },
    onSuccess: (user: User) => {
      queryClient.setQueryData(["/api/user", account], user);
      toast({
        title: "Authentication successful",
        description: "Welcome to Fantasma Firewall",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Authentication failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/user", account], null);
      toast({
        title: "Logged out",
        description: "You have been logged out successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return {
    user: user || null,
    isLoading,
    error,
    walletAuthMutation,
    logoutMutation,
    isAuthenticated: !!user && !!account && isConnected,
  };
}