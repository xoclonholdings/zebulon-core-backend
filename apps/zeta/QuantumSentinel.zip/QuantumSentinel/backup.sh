#!/bin/bash

# Fantasma Firewall Backup Script
# Automated backup for application and database

set -e

# Configuration
APP_NAME="fantasma-firewall"
APP_DIR="/var/www/$APP_NAME"
BACKUP_DIR="/backups/$APP_NAME"
DB_NAME="fantasma_firewall"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=7

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[BACKUP]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Create backup directory
create_backup_dir() {
    if [ ! -d "$BACKUP_DIR" ]; then
        sudo mkdir -p "$BACKUP_DIR"
        sudo chown $USER:$USER "$BACKUP_DIR"
        print_status "Created backup directory: $BACKUP_DIR"
    fi
}

# Backup database
backup_database() {
    print_status "Backing up database..."
    
    DB_BACKUP_FILE="$BACKUP_DIR/${DB_NAME}_${DATE}.sql"
    pg_dump "$DB_NAME" > "$DB_BACKUP_FILE"
    
    # Compress backup
    gzip "$DB_BACKUP_FILE"
    
    print_status "Database backup created: ${DB_BACKUP_FILE}.gz"
}

# Backup application files
backup_application() {
    print_status "Backing up application files..."
    
    APP_BACKUP_FILE="$BACKUP_DIR/${APP_NAME}_${DATE}.tar.gz"
    
    tar -czf "$APP_BACKUP_FILE" \
        -C "$(dirname $APP_DIR)" \
        --exclude='node_modules' \
        --exclude='dist' \
        --exclude='.git' \
        --exclude='*.log' \
        "$(basename $APP_DIR)"
    
    print_status "Application backup created: $APP_BACKUP_FILE"
}

# Backup configuration files
backup_configs() {
    print_status "Backing up configuration files..."
    
    CONFIG_BACKUP_FILE="$BACKUP_DIR/configs_${DATE}.tar.gz"
    
    tar -czf "$CONFIG_BACKUP_FILE" \
        /etc/nginx/sites-available/$APP_NAME \
        /etc/nginx/sites-enabled/$APP_NAME \
        "$APP_DIR/.env" \
        "$APP_DIR/ecosystem.config.js" \
        2>/dev/null || true
    
    print_status "Configuration backup created: $CONFIG_BACKUP_FILE"
}

# Backup PM2 configuration
backup_pm2() {
    print_status "Backing up PM2 configuration..."
    
    PM2_BACKUP_FILE="$BACKUP_DIR/pm2_${DATE}.json"
    pm2 save
    cp ~/.pm2/dump.pm2 "$PM2_BACKUP_FILE"
    
    print_status "PM2 backup created: $PM2_BACKUP_FILE"
}

# Cleanup old backups
cleanup_old_backups() {
    print_status "Cleaning up old backups (older than $RETENTION_DAYS days)..."
    
    find "$BACKUP_DIR" -name "*_20*" -type f -mtime +$RETENTION_DAYS -delete
    
    print_status "Old backups cleaned up"
}

# Verify backups
verify_backups() {
    print_status "Verifying backups..."
    
    # Check if backup files exist and are not empty
    if [ -s "$BACKUP_DIR/${DB_NAME}_${DATE}.sql.gz" ]; then
        print_status "✓ Database backup verified"
    else
        print_error "Database backup verification failed"
        exit 1
    fi
    
    if [ -s "$BACKUP_DIR/${APP_NAME}_${DATE}.tar.gz" ]; then
        print_status "✓ Application backup verified"
    else
        print_error "Application backup verification failed"
        exit 1
    fi
    
    print_status "All backups verified successfully"
}

# Display backup summary
backup_summary() {
    echo ""
    echo "Backup Summary"
    echo "=============="
    echo "Date: $(date)"
    echo "Backup Directory: $BACKUP_DIR"
    echo ""
    echo "Files created:"
    ls -lh "$BACKUP_DIR"/*_${DATE}* 2>/dev/null || echo "No backups found"
    echo ""
    echo "Disk usage:"
    du -sh "$BACKUP_DIR"
    echo ""
}

# Main backup function
main() {
    print_status "Starting backup process..."
    
    create_backup_dir
    backup_database
    backup_application
    backup_configs
    backup_pm2
    verify_backups
    cleanup_old_backups
    backup_summary
    
    print_status "Backup completed successfully!"
}

# Run backup
main "$@"