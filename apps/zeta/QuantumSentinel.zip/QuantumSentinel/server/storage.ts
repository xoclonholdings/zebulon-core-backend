// Import from the simple storage module which contains the working implementation
export * from './storage-simple';