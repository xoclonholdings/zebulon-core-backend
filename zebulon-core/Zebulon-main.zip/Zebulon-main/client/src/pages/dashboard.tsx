import ZebulonSimple from "@/components/ZebulonSimple";

export default function Dashboard() {
  return <ZebulonSimple />;
}
